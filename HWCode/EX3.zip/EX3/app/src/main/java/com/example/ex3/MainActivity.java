package com.example.ex3;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.example.ex3.ui.login.LoginActivity;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    //实例化全部控件，需跟id绑定分开，否则会出现严重bug
    TextView user;//用户名
    EditText leftnum;//左输入
    EditText rightnum;//右输入
    TextView currentCal;//当前运算法则
    TextView result;//结果
    Button calculateBtn;//计算按钮
    Button clearBtn;//清除按钮
    Button returnBtn;//返回按钮
    CheckBox checkBox;//复选框
    String username;//用户名
    //实例化计算类
    CalculateClass calculator = new CalculateClass();

    public void refresh() {
        //刷新方法，将需要修改的变量进行刷新，建议在每次修改后调用此方法
        leftnum.setText(calculator.getLeftnum());
        rightnum.setText(calculator.getRightnum());
        //传入左右操作数
        calculator.setLeftnum(leftnum.getText().toString());
        calculator.setRightnum(rightnum.getText().toString());
        currentCal.setText(calculator.getResult1());
        if (checkBox.isChecked()&&calculator.getOperator().equals("/")&&calculator.calculateRemainder()!=0) {
            //如果复选框被选中，则以余数形式展现结果
            double resultDouble = calculator.getResult();
            int resultInt = (int) resultDouble;
            double resultReminder = (calculator.calculateRemainder());
            //将resultReminder保留三位小数
            resultReminder = (double) Math.round(resultReminder * 1000) / 1000;
            String resultString = String.valueOf(resultInt) + "..." + String.valueOf(resultReminder);
            result.setText(resultString);
        } else {
            //valueOf将浮点数转换为字符串
            result.setText(String.valueOf(calculator.getResult()));
        }

    }


    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //接收intent传入的用户名
        username = getIntent().getStringExtra("username");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*实例化全部控件，此处容易出现一个不报错的严重bug，因为实例化各控件时同时进行了id的绑定，
        但是若此时layout未加载，则程序闪退，因此实例化控件时不要绑定id，id绑定在setContentView(R.layout.activity_main);之后进行
         */
        user = findViewById(R.id.textView);//用户名
        leftnum = findViewById(R.id.editTextNumber);//左输入
        rightnum = findViewById(R.id.editTextNumber2);//右输入
        currentCal = findViewById(R.id.textView7);//当前运算法则
        result = findViewById(R.id.textView9);//结果
        returnBtn = findViewById(R.id.button);//返回按钮
        calculateBtn = findViewById(R.id.button2);//计算按钮
        clearBtn = findViewById(R.id.button3);//清除按钮
        checkBox = findViewById(R.id.checkBox);//复选框
        checkBox.isActivated();


        //初始化，防止空字符
        leftnum.setText("1");
        rightnum.setText("1");
        //修改用户名
        user.setText("user:"+username);

        //实例化listView
        ListView listView = findViewById(R.id.listView);
        //创建数据源
        ArrayList<String> data = new ArrayList<>();
        data.add("+");
        data.add("-");
        data.add("*");
        data.add("/");
        //创建适配器
        ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, data);
        //绑定适配器
        listView.setAdapter(adapter);

        //设置listView的点击事件
        listView.setOnItemClickListener((parent, view, position, id) -> {
            //获取点击的内容
            String content = data.get(position);
            //设置运算符
            calculator.setOperator(content);
            calculator.calculate();
            //刷新
            refresh();
        });

        //设置editText的监听事件
        leftnum.setOnFocusChangeListener((v, hasFocus) -> {
            //判断是否获取焦点
            if (!hasFocus) {
                //获取焦点后，将输入的内容设置为左操作数
                calculator.setLeftnum(leftnum.getText().toString());
                calculator.calculate();
                //刷新
                refresh();
            }
        });
        rightnum.setOnFocusChangeListener((v, hasFocus) -> {
            //判断是否获取焦点
            if (!hasFocus) {
                //获取焦点后，将输入的内容设置为右操作数
                calculator.setRightnum(rightnum.getText().toString());
                calculator.calculate();
                //刷新
                refresh();
            }
        });
        //设置calculate按键的监听事件
        calculateBtn.setOnClickListener(v -> {
            //计算并刷新
            calculator.calculate();
            refresh();
        });
        //设置clear按键的监听事件
        clearBtn.setOnClickListener(v -> {
            //回到初始状态
            calculator.setLeftnum("1");
            calculator.setRightnum("1");
            calculator.setOperator("+");
            calculator.calculate();
            refresh();
            currentCal.setText(" ");
            result.setText("");
        });
        //设置checkBox的监听事件
        checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            //判断是否被选中
            refresh();
        });
        //设置return按键的监听事件
        returnBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            //回传用户名
            intent.putExtra("username", username);
            startActivity(intent);
            finish();

        });

    }

}