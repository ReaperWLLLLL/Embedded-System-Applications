package com.example.ex3;

public class CalculateClass {
    //成员变量包括三个字符串，分别是左操作数，右操作数，运算符
    private String leftnum;
    private String rightnum;
    private String operator;
    //两个double型变量，分别是左操作数，右操作数
    private double leftnum1;
    private double rightnum1;
    //一个double型变量，用于存储结果
    private double result;
    //一个字符串，用于存储结果
    private String result1;
    //一个int，用来表示运算符号，定义0为加法，1为减法，2为乘法，3为除法
    private int operatorNum;

    public CalculateClass() {
        //构造函数，初始化成员变量
        this.leftnum = "1";
        this.rightnum = "1";
        this.operator = "+";
        this.leftnum1 = 1;
        this.rightnum1 = 1;
        this.result = 2;
        this.result1 = "1+1";
        this.operatorNum = 0;
    }

    //set方法，用于设置左右操作数和运算符
    public void setLeftnum(String leftnum) {
        try{
            if (leftnum.equals("")){
                throw new Exception("leftnum is null");
            }
        } catch (Exception e) {
            return;
        }
        this.leftnum = leftnum;
        this.leftnum1 = Double.parseDouble(leftnum);
    }

    public void setRightnum(String rightnum) {
        try{
            if (rightnum.equals("")){
                throw new Exception("rightnum is null");
            }
        } catch (Exception e) {
            return;
        }
        this.rightnum = rightnum;
        this.rightnum1 = Double.parseDouble(rightnum);
    }

    public void setOperator(String operator) {
        this.operator = operator;
        switch (operator) {
            case "+":
                this.operatorNum = 0;
                break;
            case "-":
                this.operatorNum = 1;
                break;
            case "*":
                this.operatorNum = 2;
                break;
            case "/":
                this.operatorNum = 3;
                break;
        }
    }

    //get方法，用于获取左右操作数和运算符
    public String getLeftnum() {
        return leftnum;
    }

    public String getRightnum() {
        return rightnum;
    }

    public String getOperator() {
        return operator;
    }

    public Double getLeftnum1() {
        return leftnum1;
    }

    public Double getRightnum1() {
        return rightnum1;
    }

    public int getOperatorNum() {
        return operatorNum;
    }

    //计算方法，用于计算结果(并不返回，不过好像一起返回会好一点？)
    public void calculate() {
        switch (this.operatorNum) {
            case 0:
                this.result = this.leftnum1 + this.rightnum1;
                break;
            case 1:
                this.result = this.leftnum1 - this.rightnum1;
                break;
            case 2:
                this.result = this.leftnum1 * this.rightnum1;
                break;
            case 3:
                this.result = this.leftnum1 / this.rightnum1;
                break;
        }
        this.result1 = leftnum + operator + rightnum;
    }
    //计算余数的方法
    public double calculateRemainder() {
        return (this.leftnum1 % this.rightnum1);
    }

    //get方法，用于获取结果
    public Double getResult() {
        return result;
    }
    public String getResult1() {
        return result1;
    }
}
