package com.example.ex3.ui.login;

import android.app.Activity;
import android.content.Intent;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ex3.MainActivity;
import com.example.ex3.R;
import com.example.ex3.ui.login.LoginViewModel;
import com.example.ex3.ui.login.LoginViewModelFactory;
import com.example.ex3.databinding.ActivityLoginBinding;

public class LoginActivity extends AppCompatActivity {
    //为代码添加注释
    private LoginViewModel loginViewModel;//声明一个LoginViewModel对象
    private ActivityLoginBinding binding;//声明一个ActivityLoginBinding对象

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);//调用父类的onCreate方法

        binding = ActivityLoginBinding.inflate(getLayoutInflater());//加载布局文件
        setContentView(binding.getRoot());//设置布局文件

        loginViewModel = new ViewModelProvider(this, new LoginViewModelFactory())
                .get(LoginViewModel.class);//创建LoginViewModel对象

        final EditText usernameEditText = binding.username;//获取用户名编辑框
        final EditText passwordEditText = binding.password;//获取密码编辑框
        final Button loginButton = binding.login;//获取登录按钮
        final ProgressBar loadingProgressBar = binding.loading;//获取进度条
        final Button skipBtn = binding.skip;//获取跳过按钮
        //接收intent传入的用户名
        String username = getIntent().getStringExtra("username");
        //设置用户名
        usernameEditText.setText(username);

        loginViewModel.getLoginFormState().observe(this, new Observer<LoginFormState>() {
            @Override
            public void onChanged(@Nullable LoginFormState loginFormState) {
                if (loginFormState == null) {
                    return;//如果登录表单状态为空，则返回
                }
                loginButton.setEnabled(loginFormState.isDataValid());
                if (loginFormState.getUsernameError() != null) {
                    usernameEditText.setError(getString(loginFormState.getUsernameError()));//设置用户名错误提示
                }
                if (loginFormState.getPasswordError() != null) {
                    passwordEditText.setError(getString(loginFormState.getPasswordError()));//设置密码错误提示
                }
            }
        });

        loginViewModel.getLoginResult().observe(this, new Observer<LoginResult>() {
            @Override
            public void onChanged(@Nullable LoginResult loginResult) {
                if (loginResult == null) {
                    return;//如果登录结果为空，则返回
                }
                loadingProgressBar.setVisibility(View.GONE);
                if (loginResult.getError() != null) {
                    showLoginFailed(loginResult.getError());//显示登录失败
                    //清空密码栏
                    passwordEditText.setText("");
                    return;
                }
                if (loginResult.getSuccess() != null) {
                    updateUiWithUser(loginResult.getSuccess());//更新用户界面
                }
                setResult(Activity.RESULT_OK);//设置登录结果为成功
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);//创建一个意图
                //将用户名传入主活动
                intent.putExtra("username", usernameEditText.getText().toString());
                startActivity(intent);//启动主活动
                //Complete and destroy login activity once successful
                finish();
            }
        });

        TextWatcher afterTextChangedListener = new TextWatcher() {//创建文本监听器
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                loginViewModel.loginDataChanged(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString());//登录数据改变
            }
        };
        usernameEditText.addTextChangedListener(afterTextChangedListener);//为用户名编辑框添加文本监听器
        passwordEditText.addTextChangedListener(afterTextChangedListener);//为密码编辑框添加文本监听器
        passwordEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    loginViewModel.login(usernameEditText.getText().toString(),
                            passwordEditText.getText().toString());//登录
                }
                return false;//返回false
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {//为登录按钮添加点击监听器
            @Override
            public void onClick(View v) {
                loadingProgressBar.setVisibility(View.VISIBLE);//设置进度条可见
                loginViewModel.login(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString());//登录
            }
        });
        //添加skip按钮的点击监听器
        assert skipBtn != null;
        skipBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);//创建一个意图
                //将用户名传入主活动
                intent.putExtra("username", usernameEditText.getText().toString());
                startActivity(intent);//启动主活动
                //Complete and destroy login activity once successful
                finish();
            }
        });



    }

    private void updateUiWithUser(LoggedInUserView model) {
        String welcome = String.format("%s%s", getString(R.string.welcome)+" ", model.getDisplayName());//获取欢迎信息
        // TODO : initiate successful logged in experience
        Toast.makeText(getApplicationContext(), welcome, Toast.LENGTH_LONG).show();//显示欢迎信息
    }

    private void showLoginFailed(@StringRes Integer errorString) {
        Toast.makeText(getApplicationContext(), errorString, Toast.LENGTH_SHORT).show();//显示登录失败信息
    }
}